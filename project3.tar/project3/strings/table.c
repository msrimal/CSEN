#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "assert.h"
#include "set.h"
#include "stdbool.h"
/*
 *coen12/project3/strings/table.c
By : Maya Srimal
02/10/24
Description: This file seaches using hash to add, delete, or find a specific entry given by the variable "elt". In addition, this file lists all the entries that are filled ("F") and retuns them as well as destoying the set after use.

*/ 
/* Big-O: O(1)
 * This function doesn't return anything and this function serves to create a set and initalize variables inside it.
 */
struct set
{
	int count;
	char **data;
	char *flags;
	int max_value;
};
/* Big-O: O(n), n being the length of s.
 * This function creates a hash and returns hash once *s == '\0'.
 */
unsigned strhash(char *s)
{
	unsigned hash = 0;
	while(*s != '\0')
	{
		hash = 31*hash+*s ++;
	}
	return hash;
}
/* Big-O: O(n), n is the value of max_value
 * This function takes a struct named SET given by a pointer, a character variable named elt 
 * pointer, as well a boolean pointer variable found which holds the true or false indicating whether the function was successful in its search for the elt. If found = true, index is returned, else -1 is returned and found is set to false.
 */

int search(SET *sp, char* elt, bool *found)
{
       	int i = 0;
	int openSlot = -1;
	int hash = (strhash(elt) % sp->max_value);
	
       while( i < sp->max_value)
        {
		int index = (hash + i) % sp->max_value;
		if(sp->flags[index] == 'F')
		{	
               		if(strcmp(sp->data[index], elt) == 0)
                	{
				*found = true;
                        	return index;
                	}
		}
		else if(sp->flags[index] == 'D')
		{
			if (openSlot == -1)
			{
				openSlot = index;
			}
		}
		else if(sp->flags[index] == 'E')
		{
			if(openSlot == -1)
			{
				openSlot = index;
			}
			*found = false;
			return openSlot;
		}
		i++;	
        }
	*found = false;
        return openSlot;
}
/* Big-O: O(1)
 * This function takes an integer variable called maxElts in which is initalized in its parameters. This function also mallocs memory for the set and the variables inside it. In addition, sets everything inside the character array flags to the value of 'E' which means empty.
 */
SET *createSet(int maxElts)
{
	SET *sp = (SET*)malloc(sizeof(SET));
	sp->data = (char **)malloc(sizeof(char *) * maxElts);
	sp->flags = (char *)malloc(sizeof(char)* maxElts);
	sp->max_value = maxElts;
	sp->count = 0;
	int i;
	for(i=0; i < sp->max_value; i++)
	{
		sp->flags[i] = 'E';
	}
	return sp;
}

/* Big-O: O(n), n being value in max_value.
 * This function using a pointer that individually goes through each element inside flags that is equal to the value of 'F' and frees the data array that holds the corresponding information. In addition, frees the array flags as well as the pointer sp pointng to the SET.
 */
void destroySet(SET *sp)
{
	int i;
	for(i=0; i < sp->max_value; i++)
	{
		if(sp->flags[i] == 'F')
		{
			free(sp->data[i]);
		}
	}
//	free(sp->data);
//	don't double free
	free(sp->flags);
	free(sp);
}
/* Big-O: O(n), n being the value in max_value when search function is called as this is dominant in the time complexity of this function.
 * This function adds an element to the SET by first calling the search function to check if the variable elt already exists, then proceeds to duplicate the data into the character pointer copy and then sets the index inside data (what is returned from search) to the copy variable. Then concludes by setting the character array flags to 'F' (filled).
*/
void addElement(SET *sp, char *elt)
{
	bool found;
	assert(sp != NULL && elt != NULL);
	int locn = search(sp, elt, &found);
	if(!found)
	{
		assert(sp->count < sp->max_value);
		char* copy = strdup(elt);
		assert(copy != NULL);
		sp->data[locn] = copy;
		sp->flags[locn] = 'F';
		sp->count++;
	}
}
/* Big-O: O(n), n being the value in max_value when search function is called as this is domi
 * nant in the time complexity of this function.
 * This function calls the search function and if returned true sets the character array flags to 'D' indicating deletation and frees the data from that location and decreass count. Else if found! true returns.
 */
void removeElement(SET *sp, char *elt)
{
	bool found ;
	assert(sp != NULL && elt != NULL);
	int locn = search(sp, elt, &found);
	if(found == false)
	{
		return;
	}
	else if(found == true)
	{
		sp->flags[locn] = 'D';
		free(sp->data[locn]);
		sp->count--;		
	}
	return;
}
/* Big-O: O(1), no loops very basic
 * This function returns the size of filled elements inside the SET given by count which is incremented and decremented with every insertion and deletion.
 */		
int numElements(SET *sp)
{
	return sp->count;
}
/*Big-O: O(n) n being the value in max_value when search function is called as this is dominant in the time complexity of this function.
 * This function finds the data given by elt and calls the search functio to which if found returns the data inside the returned index (given by search). Else returns NULL indicating the search failed.
 */
char *findElement(SET *sp, char *elt)
{
	bool found;
	int i = search(sp, elt, &found);
	if(found)
	{
		return sp->data[i];
	}
	return NULL;
}	
/* Big-O: O(n), n being the number of elements in the array (value of max_value).
 * This function returns all the elements that are filled in data character array by mallocing memory to variable elements an setting each individual elements to their own index as seen in the if statement. Then returns elements.
 */
char **getElements(SET *sp)
{
	char** elements = (char **)malloc(sizeof(char*) * sp->count);
	int i;
	int j=0;
	for(i=0; i< sp->max_value; i++)
	{
		if(sp->flags[i]== 'F')
		{
			elements[j++]= sp->data[i];
		}
	}
	return elements;	
}
