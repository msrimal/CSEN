#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "assert.h"
#include "set.h"
#include <unistd.h>
#include "stdbool.h"
struct set
{
	int count;
	int max_value;
	void **data;
	char *flags;
	int (*compare)();
	unsigned (*hash)();
};


static int search(SET *sp, void *elt, bool *found)
{
	
	int i = 0;
        int openSlot = -1;
        int hash = ((*sp->hash)(elt) % sp->max_value);
        
       while( i < sp->max_value)
        {
                int index = (hash + i) % sp->max_value;
                if(sp->flags[index] == 'F')
                {
                        if((*sp->compare)(sp->data[index], elt) == 0)
                        {
                                *found = true;
                                return index;
                        }
                }
                else if(sp->flags[index] == 'D')
                {
                        if (openSlot == -1)
                        {
                                openSlot = index;
                        }
                }
                else if(sp->flags[index] == 'E')
                {
                        if(openSlot == -1)
                        {
                                openSlot = index;
                        }
                        *found = false;
                        return openSlot;
                }
                i++;
        }
        *found = false;
        return openSlot;
}

SET *createSet(int maxElts, int (*compare)(), unsigned (*hash)())
{
	SET *sp = (SET*)malloc(sizeof(SET));
        sp->data = (void **)malloc(sizeof(void *) * maxElts);
        sp->flags = (char *)malloc(sizeof(char)* maxElts);
        sp->max_value = maxElts;
        sp->count = 0;
        int i;
        for(i=0; i < sp->max_value; i++)
        {
                sp->flags[i] = 'E';
        }
	sp->compare = compare;
	sp->hash = hash;
	return sp;
}

void destroySet(SET *sp)
{
        free(sp->data);
        free(sp->flags);
        free(sp);
}

void addElement(SET *sp, void *elt)
{
        bool found;
        assert(sp != NULL && elt != NULL);
        int locn = search(sp, elt, &found);
        if(!found)
        {
                assert(sp->count < sp->max_value);
		//no strdup
                sp->data[locn] = elt;
                sp->flags[locn] = 'F';
                sp->count++;
        }
}

void removeElement(SET *sp, void *elt)
{
        bool found ;
        assert(sp != NULL && elt != NULL);
        int locn = search(sp, elt, &found);
	  if(found == false)
        {               
                return;
        }
        else if(found == true)
        {
                sp->flags[locn] = 'D';
        //        free(sp->data[locn]);
                sp->count--;
        }
        return;
}
int numElements(SET *sp)
{
        return sp->count;
}

void *findElement(SET *sp, void *elt)
{
        bool found;
        int i = search(sp, elt, &found);
        if(found)
        {
                return sp->data[i];
        }
        return NULL;
}

void *getElements(SET *sp)
{
        void** elements = (void **)malloc(sizeof(void*) * sp->count);
        int i;
        int j=0;
        for(i=0; i< sp->max_value; i++)
        {
                if(sp->flags[i]== 'F')
                {
                        elements[j++]= sp->data[i];
                }
        }
        return elements;
}

