#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "set.h"
#include "assert.h"


//define struct
struct set
{
	char ** x;
	int size;
	int max_value;
};

SET *createSet(int maxElts)
{
	SET *sp = (SET*)malloc(sizeof(SET));
	sp->x = (char **)malloc(sizeof(char *) * maxElts);
	sp->max_value = maxElts;
	sp->size = 0;
	return sp; 
}

void destroySet(SET *sp)
{
	int i;
	for(i=0; i < sp->size; i++)
	{
		free(sp->x[i]);
	}
	free(sp->x);
	free(sp);

}

int numElements(SET *sp)
{
	return sp->size;
	
}
void addElement(SET *sp, char*elt)
{
	assert(sp->size < sp->max_value);
	int i = search(sp,elt);
	if (i == -1)
	{	
		sp->x[sp->size] = strdup(elt);
		sp->size++;
	}
//	else if(i != -1)
//	{
//		printf("Element already exists.\n");
//	}
//	else
//	{
//		printf("Error in search.\n");
//	}
	return;
}
int search(SET *sp, char *elt)
{
	int i;
	for (i=0; i < sp->size; i++)
	{
		if(strcmp(sp->x[i], elt) == 0)
		{
			return i;
		}
	}
//	printf("Element was not found.\n");
	return -1;
}

void removeElement(SET* sp, char *elt)
{
	int i = search(sp, elt);
	if(i != -1)
	{
		sp->x[i] = sp->x[sp->size-1];
		sp->size--;
		//free(sp->x[sp->size]);
	}
	else
	{
//		printf("Element was not deleted.\n");
		return;
	}
}
char *findElement(SET *sp, char *elt)
{
	int i = search(sp, elt);
		if(i != -1)
		{
			printf("Element found.\n");
			return sp->x[i];
		}
		else
		{
			return NULL;
		}
}
char **getElements(SET *sp)
{
	char** elements = (char **)malloc(sizeof(char*) * sp->size); 
	memcpy(elements, sp->x, sizeof(char*)*sp->size);
}
		
