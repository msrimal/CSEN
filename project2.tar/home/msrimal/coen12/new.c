void destroySet(SET *sp);
deallocate
