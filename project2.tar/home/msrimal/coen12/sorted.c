#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "set.h"
#include "assert.h"
#include "stdbool.h"

//define struct
struct set
{
	char **x;
	int size;
	int max_value;
};
SET *createSet(int maxElts)
{
	SET *sp = (SET*)malloc(sizeof(SET));
	sp->x = (char **)malloc(sizeof(char *) * maxElts);
	sp->max_value = maxElts;
	sp->size = 0;
	return sp;
}

void destroySet(SET *sp)
{
	int i;
	for (i=0; i <sp->size; i++)
	{
		free(sp->x[i]);
	}
	free(sp->x);
	free(sp);
}
int numElements(SET *sp)
{
	return sp->size;
}

static int search(SET *sp, char *elt, bool *found)
{
	if(sp->size == 0)
	{
		*found = false;
	}
	int lo, hi, mid;
	lo = 0; 
	hi = sp->size-1;
	while(lo <= hi)
	{
		mid = (hi + lo)/2;
		if(strcmp(elt , sp->x[mid]) == 0)
		{
			*found = true;
			return mid;
		}
		else if(strcmp(elt , sp->x[mid]) > 0)
		{
			lo = mid + 1;
		}
		else
		{
			hi = mid-1;
		}
	}	
	*found = false;
	return lo;
}


void addElement(SET *sp, char*elt)
{
	int Ind;
//	assert(sp->size < sp->max_value);
	bool found;
	Ind = search(sp, elt, &found);	
	if(found == true)
	{
		printf("Element not found.\n");
	}
	else if (found == false)
	{
		int i;
		for (i= sp->size; i > Ind; i--)
		{
			sp->x[i] = sp->x[i-1];
		}
		sp->x[Ind] = strdup(elt);
		sp->size++;
	}
}

void removeElement(SET *sp, char *elt)
{
	int Ind;
	bool found;
	Ind = search(sp, elt, &found);
	if(found == true)
	{
		int i;
		free(sp->x[Ind]);
		for(i = Ind; i < sp->size; i++)
		{
			sp->x[i] = sp->x[i+1];
		}
		sp->size--;
	}
	else if (found == false)
	{
		printf("Element was not found.\n");
		return;
	}
}

char *findElement(SET *sp, char *elt)
{
	int Ind;
	bool found;
	Ind = search(sp, elt, &found);
	if(found == false)
	{
		return NULL;
	}
	else if(found == true)
	{
		printf("Element found.\n");
		return sp->x[Ind];
	}
}
char **getElements(SET *sp)
{
	char** elements = (char **)malloc(sizeof(char*) * sp->size);
	memcpy(elements, sp->x, sizeof(char*)*sp->size);
}	
