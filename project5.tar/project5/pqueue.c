#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "assert.h"
#include "pqueue.h"

struct pqueue
{
	int count;
	int length;
	void **data;
	int (*compare)();
};

PQ *createQueue(int (*compare)())
{
	PQ *pq = malloc(sizeof(PQ));
	pq->count = 0;
	pq->length = 10;
//	pq->data = realloc(target_pointer, new_size);
	pq->data = (void**)malloc(pq->length * sizeof(void*));
	pq->compare = compare;
	return pq;
}

void destroyQueue(PQ *pq)
{
	free(pq->data);
	free(pq);	
}

void addEntry(PQ *pq, void *entry)
{
	//if heap is full
	if(pq->count == pq->length)
	{
		pq->length *=2;
		pq->data = realloc(pq->data, pq->length * sizeof(void*));
	}
	int i = pq->count;
	pq->data[i] = entry;
	//pq *current = entry;
	
	int parent = (((i-1)/2));
	int left_child = ((i) * 2 + 1);
	int right_child = ((i) * 2 + 2);

	while (i>0 && pq->compare(pq->data[i], pq->data[parent]) < 0)
	{
		void *temp = pq->data[i];
		pq->data[i] = pq->data[parent];
		pq->data[parent] = temp;
		i = parent;
	}
	pq->count++;
		
}

void *removeEntry(PQ *pq)
{
	int i = 0;
	assert(pq->count > 0);
	void *min = pq->data[0];
	pq->count--;
	pq->data[0] = pq->data[pq->count];
	
	while(1)
	{
		 int left_child = ((i) * 2 + 1);
        	int right_child = ((i) * 2 + 2);
		int smallest = i;

		if(left_child < pq->count && pq->compare(pq->data[left_child], pq->data[smallest]) < 0)
		{
			smallest = left_child;
		}
		if(right_child < pq->count && pq->compare(pq->data[right_child], pq->data[smallest]) < 0)
		{
			smallest = right_child;
		}
		if(smallest == i)
		{
			break;
		}
		void *temp = pq->data[i];
		pq->data[i] = pq->data[smallest];
		pq->data[smallest] = temp;
		i = smallest;
			
	}
	return min;
}

int numEntries(PQ *pq)
{
	return pq->count;
}
