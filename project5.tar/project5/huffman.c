#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "pack.h"
#include "pqueue.h"
#include <ctype.h>
//Maya Srimal
//Lab 5 Part 2
//Description: This file compresses and decompresses a file using a priority quenue. 

struct node *mknode(int count, struct node  *left_node, struct node *right_node)
{
        struct node *new_node = malloc(sizeof(struct node));
     	new_node->count = count;
        new_node->parent = NULL;
        if (left_node != NULL)
        {
              left_node->parent = new_node;
        }
        if (right_node != NULL)
        {
              right_node->parent = new_node;
        }
        return new_node;
}

int cmp(struct node *t1, struct node *t2)
{
        if(t1->count < t2->count)
        {
                return -1;
        }
        else if (t1->count == t2->count)
        {
                return 0;
        }
        else
        {
                return 1;
        }
}

int depth(struct node *n)
{
	if(n == NULL)
	{
		return 0;
	}
	int bits = depth(n->parent);
	
	return bits + 1;
}
int main(int argc, char *argv[])
{
	int counts[256+1];
	int j;
	for(j=0; j<257; j++)
	{       
        	counts[j] = 0;
	}
	struct node *nodes[257]; //set all to zero

	int i;
	for(i=0; i<257; i++)
	{       
        	nodes[i] = NULL;
	}
	if(argc != 3)
	{
		return 0;
	}
	FILE *fp = fopen("input.txt", "r");		
	int c = getc(fp);
	while (c != EOF)
	{
		counts[c]++;
		c = getc(fp);
	}

	PQ *create = createQueue(cmp);	
	int l = 0;
	for(l=0; l<256; l++)
	{
		if(counts[l] != 0)
		{
			nodes[l] = mknode(counts[l], NULL, NULL);
			addEntry(create, nodes[l]);
		}
	}
	counts[256] = 0;
	nodes[256] = mknode(counts[256], NULL, NULL);
	addEntry(create, nodes[256]);	
	while (numEntries(create) > 1)
	{
		int count = 0;
		struct node *left = removeEntry(create);
		struct node *right = removeEntry(create);
		count = left->count + right->count;
		addEntry(create, mknode(count,left,right));
	}
	for(c=0; c<257; c++)
	{
		if(counts[c] != 0)
		{
			if(!isprint(c))
	                {
                	        printf("%03o", c);
        	        }
      	
			printf(": %d * ", counts[c]);
        		printf("%d bits =", depth(nodes[c]));
      	  		printf(" %d bits\n", counts[c] * depth(nodes[c]));
		}
	}
        //call pack to print out final bits
        pack(argv[1],argv[2],nodes);
 	fclose(fp);     
	return 0;
}

